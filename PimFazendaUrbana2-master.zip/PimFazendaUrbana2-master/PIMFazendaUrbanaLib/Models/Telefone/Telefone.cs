﻿namespace PIMFazendaUrbanaLib
{
    public class Telefone
    {
        //public int Id { get; set; }
        public string Numero { get; set; }
        public string DDD { get; set; }
        public bool StatusAtivo { get; set; }
    }
}
