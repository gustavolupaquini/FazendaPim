﻿namespace PIMFazendaUrbanaLib
{
    public class Insumo
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
        public int Qtd { get; set; }
        public string Unidqtd { get; set; }
        public bool Ativo { get; set; }
    }
}
