﻿namespace PIMFazendaUrbanaLib
{
    public class UserInactiveException : Exception
    {
        public UserInactiveException(string message) : base(message)
        {

        }
    }
}
