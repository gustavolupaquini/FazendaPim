﻿namespace PIMFazendaUrbanaAPI.DTOs
{
    public class TelefoneDTO
    {
        //public int Id { get; set; }
        public string DDD { get; set; }
        public string Numero { get; set; }
        public bool StatusAtivo { get; set; }
    }
}
