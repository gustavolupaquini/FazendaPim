﻿namespace PIMFazendaUrbanaAPI.DTOs
{
    public class LoginDTO // DTO só para realizar o login
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

}
