﻿namespace PIMFazendaUrbanaRadzen.Services
{
    public class ApiError
    {
        public string Campo { get; set; }
        public string Mensagem { get; set; }
    }
}
