﻿namespace PIMFazendaUrbanaRadzen.Services
{
    public class ApiErrorResponse
    {
        public List<ApiError> Errors { get; set; }
    }
}
